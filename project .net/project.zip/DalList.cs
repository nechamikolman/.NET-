public class DalList : IDal
{
}